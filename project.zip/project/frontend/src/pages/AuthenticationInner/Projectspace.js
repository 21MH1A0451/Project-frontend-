import { useState } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Button } from "reactstrap";
import image1 from 'assets/images/poster.jpg'; 
import "./Projectspace.css"; // Import your CSS file
import { Card, CardHeader, CardContent, Divider, Grid, Typography } from '@mui/material';
import React from 'react';
//Import Images
import logoImage from 'assets/images/u.jpeg'
import img1 from "assets/images/img1.jpg";
import img2 from "assets/images/img9.jpg";
import img3 from "assets/images/p5.jpg";
import img5 from "assets/images/img5.jpg";
import img6 from "assets/images/p4.jpg";
import img7 from 'assets/images/event.jpg'
import img from 'assets/images/img.jpg'
const Projectspace = () => {
  document.title = "Projectspace";
    const gridSpacing = 3;
    const sliderImages = [image1, img7];

    // Slider settings
    const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true, // Enable autoplay
      autoplaySpeed: 2000, // Set autoplay speed in milliseconds (e.g., 2000ms = 2 seconds)
    };
  return (
      <React.Fragment>
         
        <div className="shadow-md w-full bg-white">
        <div className="md:flex items-center justify-between  ">
        <div className="button-container fixed  py-4 md:px-10 px-7  ">
        <Button color="#2f3f50" className="button"><a className="text-dark duration-500 cursor-pointer "
              href="http://localhost:3000/ongo">upcoming Events</a></Button> 
        <Button color="#2f3f50" className="button"><a className="text-dark duration-500 cursor-pointer"
              href="http://localhost:3000/pa">Past Events</a></Button>
               
      <Button color="#2f3f50" className="button"><a className="text-dark duration-500 cursor-pointer"
              href="http://localhost:3000/login">Admin</a></Button>
      <Slider {...settings}>
          {sliderImages.map((image, index) => (
          <div key={index}>
            <img src={image} alt={`Slider Image ${index}`} className="slider-image" />
            </div>
            ))}
         </Slider>
    </div>
          
        </div>
      </div>
      <br/>
      <Grid container spacing={gridSpacing}>
        <Grid item>
          <Card className="c">
            <CardHeader
              title={
                <Typography component="div" className="card-header"  id = "INTRODUCTION">
                    <h4><center><b >Alumni Meet</b></center></h4>
                </Typography>
              }
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" className='b'>
              <center><img src = {img1} alt = ""/></center>
                <br/>
              <p>Alumni associations are mainly organized around universities or departments of universities, but may also be organized among students that studied in a certain country. In the past, they were often considered to be the university's or school's old boy society (or Old boy network)
                . Today, alumni associations involve graduates of all age groups and demographics.
            </p>
               {/* <br/> */}
              {/* <center><img src = {eca} alt=''/></center> */}
              </Typography>
            </CardContent>
          </Card>
          <Card className="c">
            <CardHeader
              title={
                <Typography component="div" className="card-header"  id = "INTRODUCTION">
                <h4><center><b >Veda 2k23 </b></center></h4>
                </Typography>
              }
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" className='b'>
              <center><img src = {img2} alt = ""/></center>
                <br></br>
            <p>
              VEDA is a technical fest conducted at the ADITYA CAMPUS for extracting
              the hidden talents in the students and to for their carrier motivation. This is 
              conducted in the month of September of every year. All the surrounding colleges are invited 
              for the participation .Interesting aspects like ROBOTICS is conducted.
            </p>
               {/* <br/> */}
              {/* <center><img src = {eca} alt=''/></center> */}
              </Typography>
            </CardContent>
          </Card>
          <Card className="c">
            <CardHeader
              title={
                <Typography component="div" className="card-header"  id = "INTRODUCTION">
                  <h4><center><b >shivaratri</b></center></h4>
                </Typography>
              }
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" className='b'>
              <center><img src = {img3} alt = ""/></center>
                <br></br>
              <p>Shivaratri, also known as Maha Shivaratri, is one of the most significant Hindu festivals dedicated
                 to Lord Shiva. Shivaratri falls on the 14th night of the lunar month of Phalguna or Maagha, usually in February or March. Overall, Shivaratri celebrations in your college are a time of reverence, devotion, and spiritual awakening. They provide an opportunity for students and faculty members to deepen their connection with Lord Shiva,
                 seek his blessings.
            </p>
               {/* <br/> */}
              {/* <center><img src = {eca} alt=''/></center> */}
              </Typography>
            </CardContent>
          </Card>
          <Card className="c">
            <CardHeader
              title={
                <Typography component="div" className="card-header"  id = "INTRODUCTION">
                  <h4><center><b >Women's Day</b></center></h4>
                </Typography>
              }
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" className='b'>
              <center><img src = {img6} alt = ""/></center>
                <br></br>
              <p>International Women's Day is a global day celebrating the social, economic,
                 cultural, and political achievements of women. The day also marks a call to action 
                 for accelerating gender parity. Significant activity is witnessed worldwide as groups
                  come together to celebrate women's achievements or rally for women's equality.
            </p>
               {/* <br/> */}
              {/* <center><img src = {eca} alt=''/></center> */}
              </Typography>
            </CardContent>
          </Card>
          <Card className="c">
            <CardHeader
              title={
                <Typography component="div" className="card-header"  id = "INTRODUCTION">
                  <h4><center><b >Ganesh Chaturdhi</b></center></h4>
                </Typography>
              }
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" className='b'>
              <center><img src = {img5} alt = ""/></center>
                <br></br>
              <p>At the start of the festival, idols of Ganesha are placed in hostels. The worship begins
                 with the pranapratishtha, a ritual to invoke life in the idols, followed by shhodashopachara,
                 or the 16 ways of paying tribute.At the conclusion of the festival, the idols are carried 
                  local rivers in huge processions accompanied by devotional singing and dancings.
            </p>
              </Typography>
            </CardContent>
          </Card>
          <Card className="c">
            <CardHeader
              title={
                <Typography component="div" className="card-header"  id = "INTRODUCTION">
                  <h4><center><b >Achiever's Day</b></center></h4>
                </Typography>
              }
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" className='b'>
              <center><img src = {img} alt = ""/></center>
                <br></br>
              <p>The Dream of many graduates is to achieve a job.
                 Aditya celebrates the ACHIEVERS DAY -2k23 to congratulate all its 
                 achievers who laid a new mile stone for the year.
            </p>
              </Typography>
            </CardContent>
          </Card>
          <card>
            <cardbody>

            </cardbody>
          </card>
        </Grid>
      </Grid>
      </React.Fragment>
  );
}

export default Projectspace;
